package test;

import core.baseTest;
import function.editSellpage_function;
import function.login_function;
import function.seller_function;
import org.testng.annotations.Test;

public class editSellpage extends baseTest {

    @Test
    public void TC02_editSellpage() throws InterruptedException {
        login_function loginFunction = new login_function(driver);
//        loginFunction.login("tuyennt@aionbyte.com", "aion@123");
        loginFunction.login("tuyennguyen.aion@example.com", "eHighway@123");

        seller_function sellerFunction = new seller_function(driver);
        Thread.sleep(5000);
        sellerFunction.viewEditSellpgage();
        Thread.sleep(5000);

        editSellpage_function editSellpageFunction= new editSellpage_function(driver);
        editSellpageFunction.editSellpagePage();
        Thread.sleep(5000);

        editSellpageFunction.uploadFileLogo();

        editSellpageFunction.uploadFivacon();

        editSellpageFunction.editTitleSellpage();

        editSellpageFunction.scrollToTitle();
        editSellpageFunction.uploadMedia();

        editSellpageFunction.editPriceVariants();

        editSellpageFunction.createCombo();

        editSellpageFunction.clickQuantityDiscount();

        editSellpageFunction.inputDiscount1();

        editSellpageFunction.addReview();

//        editSellpageFunction.scrollToDescription();
        editSellpageFunction.editDescription();

        driver.switchTo().defaultContent();

        editSellpageFunction.clickSavePublic();

        Thread.sleep(5000);

    }

}
