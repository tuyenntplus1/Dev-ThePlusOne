package sellerPortal.page;

import org.openqa.selenium.By;

public class requestFulfill_page {
    public By titleRequestFulfill = By.xpath("//main//span[contains(text(),'Request fulfill')]");
    public By productNameRequest = By.xpath("//div[@class='d-flex h-100']/div[2]/div/div/div/div/span[2]");
}
