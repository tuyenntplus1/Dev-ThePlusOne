package test;

import core.baseTest;
import core.excelUtils;
import function.*;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CreateSellpage extends baseTest {


    @DataProvider()
    public static Object[][] getLogin() {
        String path = "seller/seller.xlsx";
        String sheetName = "login";
        return excelUtils.getTableArray(path, sheetName, 0, 2);
    }
    @Test(dataProvider = "getLogin")
    public void CreateEhighwaySellpage(String email, String pass) throws InterruptedException {
        login_function loginFunction = new login_function(driver);
        loginFunction.login(email, pass);
        productPublic_function productPublicFunction = new productPublic_function(driver);
        productPublicFunction.searchProduct("Products for test automation");
        Thread.sleep(3000);

        productPublicFunction.hoverImage();
        productPublicFunction.sellThisProduct();

        theme_function themeFunction = new theme_function(driver);
        themeFunction.hoverImageRevenue();
        themeFunction.clickCreateSellpage();

        createDomain_function createDomainFunction = new createDomain_function(driver);
        createDomainFunction.createEhighwayDomain();
//        createDomainFunction.clickConfirmBtn();
//
//        editSellpage_function editSellpageFunction = new editSellpage_function(driver);
//        editSellpageFunction.verifyCreateSellpage();
//
//        String s1 = driver.getCurrentUrl();
//
//        System.out.println(s1);

    }
    @Test(dataProvider = "getLogin")
    public void createCustomizeDomain(String email, String pass) throws InterruptedException {
        login_function loginFunction = new login_function(driver);
        loginFunction.login(email, pass);
        productPublic_function productPublicFunction = new productPublic_function(driver);
        productPublicFunction.searchProduct("Products for test automation");
        Thread.sleep(3000);

        productPublicFunction.hoverImage();
        productPublicFunction.sellThisProduct();

        theme_function themeFunction = new theme_function(driver);
        themeFunction.hoverImageRevenue();
        themeFunction.clickCreateSellpage();

        createDomain_function createDomainFunction = new createDomain_function(driver);
        createDomainFunction.createCustomizeDomain();
    }

}