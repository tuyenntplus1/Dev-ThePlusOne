package buyerCheckOut.page;

import org.openqa.selenium.By;

public class checkout_page {
    //paypal
    public By headerPaypalForm = By.id("headerText");
    public By email = By.id("email");
    public By nextBtn = By.id("btnNext");
    public By password = By.id("password");
    public By loginBtn= By.id("btnLogin");
    public By submitBtn = By.id("payment-submit-btn");
}

