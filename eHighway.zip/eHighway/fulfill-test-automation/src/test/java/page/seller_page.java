package page;

import org.openqa.selenium.By;

public class seller_page {
    public By nav = By.xpath("//aside");
    public By collapse =By.xpath("//img[@class='ant-image-img sidebar_collapseIcon__9mnvD']//parent::div");
    public By sellpages =By.xpath("//div[@class='sidebar_aside__body__lists__LcB6C'][1]/div[1]");
    public By sellpageTest = By.xpath("//span[contains(text(),'Sellpages test')]");
    public By sellpage1 = By.xpath("//tbody/tr[2]");
    public By action = By.xpath("//tbody/tr[2]/td[7]/div[1]/*[1]");

    public By editSellpageBtn = By.xpath("//span[contains(text(),'Edit sellpage')]");
    public By productsNav = By.xpath("//span[contains(text(),'Products')]");
    public By myProductsNav = By.xpath("//span[contains(text(),'My products')]");

}
