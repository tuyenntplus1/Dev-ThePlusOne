package page;

import org.openqa.selenium.By;

public class editSellpage_page {
    public By titleEditSellpage = By.xpath("//div[contains(text(),'Edit sellpages')]");
    public By chooseLogo = By.xpath("//div[@id='logo']//descendant::button");
    public  By chooseFavicon = By.xpath("//div[@id='favicon']//descendant::button");
//    public By titleSellpage = By.xpath("//div[@id='title']//descendant::input");
    public By titleSellpage = By.xpath("//input[@id='title']");
    public By addMedia= By.xpath("//div[@id='media']//descendant::div[contains(text(),'Add media')]");

//    public By priceVariant1= By.xpath("//div[@id='variant']//tbody/tr[2]/td[4]");
//    public By priceVariant1 = By.xpath("//tbody/tr[2]/td[4]/div[1]/div[1]/div[2]/input[1]");
    public By priceVariant1 = By.xpath("//tbody/tr[2]/td[4]/div/div/div[2]/input");
    public By priceVariant2 = By.xpath("//tbody/tr[3]/td[4]/div/div/div[2]/input");

    public By iframeDescription = By.xpath("//div[@id='description']//iframe [@title='Rich Text Area']");

    public By description = By.xpath("//body[@id='tinymce']");

    public By selectTitle= By.xpath("//div[@class='ant-col ant-col-xs-5']/div/div/span/input");

    public By addQuantityDiscount = By.xpath("//span[contains(text(),'Add quantity discount')]");

    public By inputDiscount1 = By.xpath("//span[contains(text(),'Add quantity discount')]//preceding::input[1]");
//review
    public By addReview = By.xpath("//div[@class='review_review__item__gHDi1']/div");
    public By nameReview= By.id("control-ref_name");
    public By emailReview = By.xpath("//input[@id='control-ref_email']");
    public By titleReview = By.xpath("//input[@id='control-ref_title']");
    public By addImageReview = By.xpath("//div[contains(text(),'Add Image')]");
    public By descriptionReview = By.id("control-ref_description");
//    public By saveReviewBtn= By.xpath("//body[1]/div[12]/div[1]/div[2]/div[1]/div[2]/div[2]/form[1]/div[3]/div[2]/button[1]/span[1]");
    public By saveReviewBtn= By.xpath("//form[@id='control-ref']//span[contains(text(),'Save')]//parent::button");
    public By savePublicBtn =By.xpath("//span[contains(text(),'Save and publish')]");
    //combo
    public By upsell= By.id("upsell");
    public By addCombo= By.xpath("//span[contains (text(),'Add Another Combo')]");
//    public By addImageCombo = By.xpath("//div[contains(text(),'Change')]");
    public By addImageCombo = By.xpath("//span[contains(text(),'Add Image')]//ancestor::div[3]");
    public By iframeImageCombo = By.xpath("//body/iframe[1]");
    public  By imageCombo= By.xpath("//body/div[12]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/img[1]");
    public By comboName =  By.xpath("//input[@placeholder ='Combo name']");
    public By comboPrice = By.xpath("//input[@placeholder ='Combo price']");
    public By compareComboPrice = By.xpath("//input[@placeholder ='Compare at combo price']");
    public By addVariansBtn= By.xpath("//span[contains(text(),'Add variant')]");
//    public By selectVariant = By.xpath("//span[contains(text(),'Select variants')]");
    public By selectVariant = By.xpath("//span[contains(text(),'Select variants')]//preceding::input[1]");
    public By iframeVariantCombo = By.xpath("//iframe[@src='//r.zozezop.com/statistic?url=https%3A%2F%2Fseller.ehighway.co%2Flogin%3FreturnUrl%3D%252Fsellpages%252F64814a15fc3ccbf79b89742f%253Ftab%253Dtest&id=dc9893e8-c57f-4186-a0cb-f8d8b1347faf']");
    public By variantCombo1 = By.xpath("//div[contains(text(),'Purple - L ')]");
    public By variantCombo2 =By.xpath("//body/div[14]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[8]/div[1]");




}
