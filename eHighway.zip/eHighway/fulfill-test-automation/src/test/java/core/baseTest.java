package core;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.time.Duration;

public class baseTest {
    public WebDriver driver;
    @BeforeMethod
    public void setup(){
        driver =new ChromeDriver();
        WebDriverManager.chromedriver().setup();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
//        String url ="https://seller.ehighway.co/login";
        String url ="https://seller.staging.ehighway.co/login";
        driver.get(url);
    }
    @AfterMethod
    public void teardown(){
        driver.quit();
    }
}


