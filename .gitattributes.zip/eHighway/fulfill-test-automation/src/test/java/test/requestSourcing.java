package test;

import core.baseTest;
import function.login_function;
import function.myProducts_function;
import function.seller_function;
import org.testng.annotations.Test;

public class requestSourcing extends baseTest {
    @Test
    public void requestSourcing1() throws InterruptedException {
        login_function loginFunction = new login_function(driver);
//        loginFunction.login("tuyennt@aionbyte.com", "aion@123");
        loginFunction.login("tuyennguyen.aion@example.com", "eHighway@123");
//        loginFunction.login("botige6044@aaorsi.com", "tWvgKT9t");
        seller_function sellerFunction = new seller_function(driver);
        sellerFunction.viewMyProducts();
        myProducts_function myProductsFunction = new myProducts_function(driver);
        myProductsFunction.requestSourcing();
    }
}
