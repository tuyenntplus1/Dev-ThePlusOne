package function;

import core.basePage;
import org.openqa.selenium.WebDriver;
import page.seller_page;

public class seller_function extends basePage {
    public seller_function(WebDriver driver) {
        super(driver);
    }
    common_function commonFunction = new common_function(driver);
    seller_page sellerPage = new seller_page();
    public void viewEditSellpgage() throws InterruptedException {
        commonFunction.click(sellerPage.collapse);
        commonFunction.click(sellerPage.sellpages);
        Thread.sleep(5000);
        commonFunction.click(sellerPage.sellpageTest);
        Thread.sleep(5000);
        commonFunction.click(sellerPage.sellpage1);
//        Thread.sleep(5000);
//        commonFunction.click(sellerPage.action);
//        commonFunction.click(sellerPage.editSellpageBtn);
    }
    public  void viewMyProducts(){
        commonFunction.Hover(sellerPage.nav);
        commonFunction.click(sellerPage.collapse);
        commonFunction.click(sellerPage.productsNav);
        commonFunction.click(sellerPage.myProductsNav);
        commonFunction.click(sellerPage.collapse);
    }
}
