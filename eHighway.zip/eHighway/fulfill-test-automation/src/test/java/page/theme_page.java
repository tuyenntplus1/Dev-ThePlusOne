package page;

import org.openqa.selenium.By;

public class theme_page {
//    public By imageRevenue = By.xpath("//div[@class='ant-modal-content']/div[2]/div[1]/article[3]/div/div/div[1]");
public By imageRevenue = By.xpath("//div[@class='ant-modal-content']/div[2]/div[1]/div[4]/div/div/div/img");

//    public By createSellpageBtn = By.xpath("//div[@class='ant-modal-content']/div[2]/div[1]/article[3]/div/div/div[1]/div/button");
    public By createSellpageBtn = By.xpath("//div[@class='ant-modal-content']/div[2]/div[1]/div[4]/div/div/div/div/button");

}
