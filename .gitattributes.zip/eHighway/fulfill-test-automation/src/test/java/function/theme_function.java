package function;

import core.basePage;
import org.openqa.selenium.WebDriver;
import page.theme_page;

public class theme_function extends basePage {
    public theme_function(WebDriver driver) {
        super(driver);
    }
    common_function commonFunction = new common_function(driver);
    theme_page themePage = new theme_page();
     public void hoverImageRevenue(){
         commonFunction.Hover(themePage.imageRevenue);
     }
     public void clickCreateSellpage(){
         commonFunction.click(themePage.createSellpageBtn);
     }

}
