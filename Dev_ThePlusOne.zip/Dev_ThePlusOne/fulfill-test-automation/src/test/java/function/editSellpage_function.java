package function;

import core.basePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import page.editSellpage_page;

public class editSellpage_function extends basePage {
    common_function commonFunction = new common_function(driver);
    editSellpage_page  editSellpagePage = new editSellpage_page();

    public editSellpage_function(WebDriver driver) {
        super(driver);
    }

    public void verifyCreateSellpage(){
        commonFunction.verifySellerPage(editSellpagePage.titleEditSellpage);
    }
    public void editSellpagePage(){
        commonFunction.switchWindowByTitle("Edit sellpage");
    }
    public void chooseLogo(){
        commonFunction.click(editSellpagePage.chooseLogo);
    }
    public  void uploadFileLogo() throws InterruptedException {
//        String filePath= System.getProperty("user.dir")+"\\Aion\\logo";
       commonFunction.uploadFile(editSellpagePage.chooseLogo,"D:\\Aion\\logo.png");
    }
    public void uploadFivacon() throws InterruptedException {
        commonFunction.uploadFile(editSellpagePage.chooseFavicon,"D:\\Aion\\icon.jpg");
    }
    public void scrollToTitle() throws InterruptedException {
        commonFunction.scroll(editSellpagePage.titleSellpage);
    }
    public void editTitleSellpage() throws InterruptedException {
        commonFunction.senKeyPrice(editSellpagePage.titleSellpage,"Zipper Quick Dry Sport Jacket Outwear For Yoga Gym Professional");
    }
    public void uploadMedia() throws InterruptedException {
        commonFunction.uploadFile(editSellpagePage.addMedia,"D:\\Aion\\logo.png");
    }
    public void editPriceVariants() throws InterruptedException {
        commonFunction.senKeyPrice(editSellpagePage.priceVariant1,"50");
        commonFunction.senKeyPrice(editSellpagePage.priceVariant2,"51");
    }
    public void editDescription() throws InterruptedException {
        commonFunction.scroll(editSellpagePage.iframeDescription);
        commonFunction.switchIframe(editSellpagePage.iframeDescription);
        commonFunction.senKeys(editSellpagePage.description,"Zipper Quick Dry Sport Jacket Outwear For Yoga Gym Professional\n" +
                "Material: NYLON\n" +
                "Material: spandex\n" +
                "Feature: Anti-Wrinkle\n" +
                "Feature: Anti-Pilling\n" +
                "Feature: Waterproof\n" +
                "Feature: Quick Dry\n" +
                "Feature: Windproof\n" +
                "Collar: MANDARIN COLLAR\n"+
                "Zipper Quick Dry Sport Jacket Outwear For Yoga Gym Professional");
    }
    public void selectUpsellBuilder() throws InterruptedException {
        commonFunction.selectDropdown(editSellpagePage.selectTitle,"Upsell Builder");
    }
    public void clickQuantityDiscount(){
        commonFunction.click(editSellpagePage.addQuantityDiscount);
    }
    public void inputDiscount1() throws InterruptedException {
        commonFunction.senKeys(editSellpagePage.inputDiscount1,"20");
    }
    public void addReview() throws InterruptedException {
        commonFunction.click(editSellpagePage.addReview);
        commonFunction.senKeys(editSellpagePage.nameReview,"Tuyen Nguyen");
        commonFunction.senKeys(editSellpagePage.emailReview,"tuyennt@ehighway.co");
        commonFunction.senKeys(editSellpagePage.titleReview,"Product");
//        commonFunction.uploadFile(editSellpagePage.addImageReview,"D:\\Aion\\logo.png");
        commonFunction.uploadFile(editSellpagePage.addImageReview,"D:\\Aion\\ảnh test\\áo\\áo tím.webp");
        commonFunction.senKeys(editSellpagePage.descriptionReview,"Nice product good value for money");
        commonFunction.click(editSellpagePage.saveReviewBtn);
    }
    public void createCombo() throws InterruptedException {
        commonFunction.scroll(editSellpagePage.upsell);
        commonFunction.click(editSellpagePage.addCombo);

        commonFunction.click(editSellpagePage.addImageCombo);
//        commonFunction.switchIframe(editSellpagePage.iframeImageCombo);

        commonFunction.click(editSellpagePage.imageCombo);
        driver.switchTo().defaultContent();
        commonFunction.click(editSellpagePage.addVariansBtn);
        commonFunction.click(editSellpagePage.selectVariant);

//        commonFunction.switchIframe(editSellpagePage.iframeVariantCombo);
        commonFunction.click(editSellpagePage.variantCombo1);

        commonFunction.click(editSellpagePage.addVariansBtn);
        commonFunction.click(editSellpagePage.selectVariant);
        commonFunction.click(editSellpagePage.variantCombo2);
//        commonFunction.selectByVisibleText(editSellpagePage.selectVariant,"Purple - M ");
        commonFunction.senKeys(editSellpagePage.comboName,"Set couple");
        commonFunction.senKeyPrice(editSellpagePage.comboPrice,"80");
        commonFunction.senKeyPrice(editSellpagePage.compareComboPrice,"95");
    }
//    public void scrollToDescription() throws InterruptedException {
//        commonFunction.scroll(editSellpagePage.iframeDescription);
//    }
    public void clickSavePublic(){
        commonFunction.click(editSellpagePage.savePublicBtn);
    }

}
