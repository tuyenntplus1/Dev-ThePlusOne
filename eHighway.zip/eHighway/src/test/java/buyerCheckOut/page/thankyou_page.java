package buyerCheckOut.page;

import org.openqa.selenium.By;

public class thankyou_page {
    public By textThankyou = By.xpath("//div[@id='__next']/div/div/div/div/span");
}

